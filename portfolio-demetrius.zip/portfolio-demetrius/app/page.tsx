import Link from "next/link";
import { ArrowUpRight, Code2, GraduationCap, BriefcaseBusiness } from "lucide-react";

export default function Home() {
  return <main>
    <section className="hero">
      <div>
        <div className="eyebrow">Portfólio · Tecnologia & desenvolvimento</div>
        <h1>Olá, eu sou<br/><em>Demetrius.</em></h1>
        <p className="lead">Estudante de Sistemas para Internet, interessado em tecnologia, desenvolvimento web e em transformar ideias em soluções digitais.</p>
        <div className="actions">
          <Link className="btn" href="/projetos">Ver meus projetos <ArrowUpRight size={17}/></Link>
          <a className="btn secondary" href="mailto:SEU_EMAIL_AQUI">Entrar em contato</a>
        </div>
      </div>
      <aside className="profile-card">
        <div className="avatar">DM</div>
        <div className="eyebrow">Sobre mim</div>
        <h2>Demetrius de Moura</h2>
        <p className="muted">Recife · Pernambuco · Brasil</p>
        <p className="muted">Em formação na área de tecnologia, com experiência profissional em rotinas administrativas e logísticas.</p>
        <div className="pill-row"><span className="pill">React</span><span className="pill">JavaScript</span><span className="pill">HTML & CSS</span><span className="pill">Java</span></div>
      </aside>
    </section>

    <section className="section">
      <div className="section-head"><div><div className="eyebrow">Navegue</div><h2>Conheça minha trajetória</h2></div></div>
      <div className="grid">
        <article className="card"><GraduationCap className="card-icon"/><h3>Formação</h3><p>Minha jornada acadêmica, cursos e aprendizados na área de tecnologia.</p><p style={{marginTop:14}}><Link className="small-link" href="/academica">Ver formação →</Link></p></article>
        <article className="card"><BriefcaseBusiness className="card-icon"/><h3>Experiência</h3><p>Vivências profissionais, responsabilidades e competências desenvolvidas.</p><p style={{marginTop:14}}><Link className="small-link" href="/profissional">Ver experiência →</Link></p></article>
        <article className="card"><Code2 className="card-icon"/><h3>Projetos</h3><p>Projetos acadêmicos e aplicações desenvolvidas durante meus estudos.</p><p style={{marginTop:14}}><Link className="small-link" href="/projetos">Ver projetos →</Link></p></article>
      </div>
    </section>
  </main>;
}