import type { Metadata } from "next";
import "./globals.css";
import SiteLayout from "@/components/SiteLayout";

export const metadata: Metadata = {
  title: "Demetrius de Moura | Portfólio",
  description: "Portfólio acadêmico e profissional de Demetrius de Moura.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body><SiteLayout>{children}</SiteLayout></body></html>;
}