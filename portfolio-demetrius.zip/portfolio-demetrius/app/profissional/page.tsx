export default function Profissional() {
  return <main>
    <div className="page-intro"><div className="eyebrow">Minha trajetória</div><h1 className="page-title">Experiência profissional</h1><p>Experiências que contribuíram para desenvolver minha organização, comunicação e familiaridade com sistemas e processos.</p></div>
    <section className="content-panel"><div className="timeline">
      <div className="timeline-item"><div className="meta">Experiência profissional</div><h3>Cobra Rolamentos — Auxiliar de Logística</h3><p className="muted">Atuação em rotinas de logística e apoio operacional, com utilização de sistemas para acompanhamento de processos e atividades relacionadas ao setor.</p><div className="tag-list"><span className="tag">Logística</span><span className="tag">SAP</span><span className="tag">Organização</span><span className="tag">Rotinas administrativas</span></div></div>
      <div className="timeline-item"><div className="meta">Experiência profissional</div><h3>Instituto Maylson Regino</h3><p className="muted">Atuação no atendimento e suporte à organização de contatos, confirmações e demandas administrativas, utilizando comunicação direta com clientes e equipe.</p><div className="tag-list"><span className="tag">Atendimento</span><span className="tag">Comunicação</span><span className="tag">Organização</span></div></div>
    </div></section>
    <section className="content-panel"><h2>Competências</h2><div className="tag-list">{["Comunicação","Trabalho em equipe","Organização","Resolução de problemas","Aprendizado contínuo","Atenção aos detalhes"].map(x=><span className="tag" key={x}>{x}</span>)}</div></section>
  </main>;
}