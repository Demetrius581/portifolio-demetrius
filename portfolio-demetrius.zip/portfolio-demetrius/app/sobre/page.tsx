export default function Sobre() {
  return <main>
    <div className="page-intro"><div className="eyebrow">Quem sou</div><h1 className="page-title">Sobre mim</h1><p>Sou estudante de Sistemas para Internet e venho construindo minha trajetória na área de tecnologia por meio da graduação, de projetos práticos e de experiências profissionais.</p></div>
    <section className="content-panel"><h2>Meu objetivo</h2><p className="muted">Busco oportunidades para aprender, desenvolver minhas habilidades e contribuir com equipes de tecnologia. Tenho interesse especial em desenvolvimento web, suporte e soluções que facilitem o dia a dia das pessoas.</p></section>
    <section className="content-panel"><h2>Tecnologias e ferramentas</h2><p className="muted">Tecnologias e ferramentas utilizadas em atividades acadêmicas e projetos pessoais. O nível de domínio evolui conforme a prática.</p><div className="tag-list">{["HTML5","CSS3","JavaScript","React","Next.js","Java","Git","GitHub","SAP","LocalStorage","SessionStorage","APIs REST"].map(x=><span className="tag" key={x}>{x}</span>)}</div></section>
    <section className="content-panel"><h2>Como gosto de trabalhar</h2><p className="muted">Valorizo a organização, a comunicação, o trabalho em equipe e a disposição para aprender. Gosto de entender o problema antes de pensar em uma solução.</p></section>
  </main>;
}