export default function Academica() {
  return <main>
    <div className="page-intro"><div className="eyebrow">Estudos e aprendizado</div><h1 className="page-title">Experiência acadêmica</h1><p>Minha formação e os conhecimentos que venho desenvolvendo para atuar na área de tecnologia.</p></div>
    <section className="content-panel"><div className="timeline">
      <div className="timeline-item"><div className="meta">Em andamento</div><h3>UNICAP — Universidade Católica de Pernambuco</h3><p className="muted">Tecnólogo em Sistemas para Internet · Recife, PE</p><p className="muted">Formação com foco em desenvolvimento de aplicações e tecnologias para a internet.</p></div>
      <div className="timeline-item"><div className="meta">Concluído</div><h3>ETE — Curso técnico em Redes</h3><p className="muted">Formação técnica na área de redes de computadores.</p></div>
      <div className="timeline-item"><div className="meta">Curso complementar</div><h3>SENAI</h3><p className="muted">Softskills em Tecnologia da Informação e Comunicação.</p></div>
    </div></section>
    <section className="content-panel"><h2>Conhecimentos trabalhados</h2><div className="tag-list">{["Lógica de programação","Programação Java","Desenvolvimento web","HTML, CSS e JavaScript","Redes de computadores","Armazenamento no navegador","Consumo de APIs"].map(x=><span className="tag" key={x}>{x}</span>)}</div></section>
  </main>;
}