import GithubLookup from "@/components/GithubLookup";

const projects = [
  {name:"ORBIT — Controle Espacial",desc:"Protótipo de painel de controle de áudio espacial, com interface para calibração e controle de volume.",tech:"HTML · JavaScript"},
  {name:"ISAC Conecta — Extração de informações",desc:"Módulo de demonstração que identifica informações como categoria, preço e contato em mensagens e organiza os dados para exportação.",tech:"HTML · CSS · JavaScript"},
  {name:"Armazenamento Web",desc:"Demonstração acadêmica dos recursos localStorage e sessionStorage, com operações de salvar e recuperar dados no navegador.",tech:"HTML · JavaScript · Web Storage"},
  {name:"REALMENTE",desc:"Proposta de projeto acadêmico voltada à criação de uma experiência digital de acolhimento e conexão, relacionada ao ODS 3.",tech:"Projeto acadêmico · Tecnologia"}
];

export default function Projetos() {
  return <main>
    <div className="page-intro"><div className="eyebrow">Prática e criação</div><h1 className="page-title">Projetos desenvolvidos</h1><p>Alguns projetos e atividades que fazem parte da minha jornada de aprendizado em tecnologia.</p></div>
    <div className="grid">{projects.map((p,i)=><article className="card" key={p.name}><div className="eyebrow">Projeto 0{i+1}</div><h3>{p.name}</h3><p>{p.desc}</p><div className="tag-list"><span className="tag">{p.tech}</span></div></article>)}</div>
    <div className="section"><GithubLookup/></div>
  </main>;
}