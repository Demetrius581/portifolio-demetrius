import Link from "next/link";
import { ReactNode } from "react";

const links = [
  ["/", "Home"],
  ["/sobre", "Sobre"],
  ["/academica", "Acadêmica"],
  ["/profissional", "Profissional"],
  ["/projetos", "Projetos"],
];

export default function SiteLayout({ children }: { children: ReactNode }) {
  return (
    <div className="site-shell">
      <header className="nav-wrap">
        <Link href="/" className="brand">demetrius<span>.</span></Link>
        <nav className="nav" aria-label="Navegação principal">
          {links.map(([href, label]) => <Link key={href} href={href}>{label}</Link>)}
        </nav>
      </header>
      {children}
      <footer className="footer">
        <span>© {new Date().getFullYear()} Demetrius de Moura</span>
        <span>Desenvolvido com Next.js · React · CSS</span>
      </footer>
    </div>
  );
}