 "use client";
import { useState } from "react";
import { Search, Github } from "lucide-react";

type Profile = { login: string; name: string | null; bio: string | null; public_repos: number; followers: number; html_url: string; avatar_url: string };

export default function GithubLookup() {
  const [username, setUsername] = useState("");
  const [profile, setProfile] = useState<Profile | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function searchProfile() {
    if (!username.trim()) { setError("Digite um nome de usuário do GitHub."); return; }
    setLoading(true); setError(""); setProfile(null);
    try {
      const response = await fetch(`https://api.github.com/users/${encodeURIComponent(username.trim())}`);
      if (!response.ok) throw new Error(response.status === 404 ? "Usuário não encontrado. Confira o nome e tente novamente." : "Não foi possível consultar a API agora.");
      setProfile(await response.json());
    } catch (e) { setError(e instanceof Error ? e.message : "Ocorreu um erro na consulta."); }
    finally { setLoading(false); }
  }

  return <section className="content-panel">
    <div className="eyebrow">Integração com API externa</div><h2><Github size={22} style={{verticalAlign:"middle",marginRight:8}}/>Consulte um perfil do GitHub</h2>
    <p className="muted">Esta seção consome a API pública do GitHub e apresenta dados reais de um perfil informado.</p>
    <div className="api-box"><input value={username} onChange={e=>setUsername(e.target.value)} onKeyDown={e=>e.key==="Enter"&&searchProfile()} placeholder="Ex.: torvalds" aria-label="Nome de usuário do GitHub"/><button className="btn" onClick={searchProfile} disabled={loading}><Search size={17}/>{loading?"Buscando...":"Buscar perfil"}</button></div>
    {error && <p role="alert" className="api-result">{error}</p>}
    {profile && <div className="api-result"><strong>{profile.name || profile.login}</strong><p>{profile.bio || "Este perfil não possui biografia pública."}</p><p>Repositórios públicos: <strong>{profile.public_repos}</strong> · Seguidores: <strong>{profile.followers}</strong></p><a className="small-link" href={profile.html_url} target="_blank" rel="noreferrer">Abrir perfil no GitHub ↗</a></div>}
  </section>;
}