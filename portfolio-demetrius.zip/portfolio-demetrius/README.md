# Portfólio — Demetrius de Moura

Projeto de portfólio pessoal desenvolvido com **Next.js, React e CSS**, com páginas separadas e integração com a API pública do GitHub.

## Páginas
- `/` — Home
- `/sobre` — Sobre e tecnologias
- `/academica` — Experiência acadêmica
- `/profissional` — Experiência profissional
- `/projetos` — Projetos e consulta à API do GitHub

## Como executar
1. Instale o Node.js (versão LTS).
2. Extraia o ZIP e abra a pasta no VS Code.
3. Abra o terminal dentro da pasta e execute:

```bash
npm install
npm run dev
```

4. Acesse http://localhost:3000

## Publicar na Vercel
1. Crie um repositório no GitHub e envie os arquivos deste projeto.
2. Entre em https://vercel.com e conecte sua conta do GitHub.
3. Importe o repositório. A Vercel identifica o Next.js automaticamente.
4. Clique em Deploy e aguarde a publicação.

## Antes de entregar
- Atualize o e-mail no botão de contato em `app/page.tsx` (substitua `SEU_EMAIL_AQUI`).
- Revise as descrições, datas e nomes de cursos/experiências para refletirem exatamente seu histórico.
- Se tiver links de GitHub, LinkedIn ou projetos publicados, adicione-os ao portfólio.
- Grave um vídeo de até 1 minuto navegando pelas páginas e mostrando a consulta à API.

## API utilizada
A página Projetos consulta `https://api.github.com/users/{username}`. Não é necessário token para a consulta pública básica. A API depende de conexão com a internet e possui limite de requisições.
